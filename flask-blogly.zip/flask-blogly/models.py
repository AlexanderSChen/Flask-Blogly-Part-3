"""Models for Blogly."""
